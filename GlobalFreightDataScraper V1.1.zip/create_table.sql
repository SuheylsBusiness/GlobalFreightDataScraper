CREATE TABLE your_table (
    CompanyId VARCHAR(255) PRIMARY KEY,
    CompanyName VARCHAR(255),
    Address TEXT,
    OfferedServices TEXT,
    Phone VARCHAR(255),
    Email VARCHAR(255),
    Website VARCHAR(255),
    Country VARCHAR(255)
);